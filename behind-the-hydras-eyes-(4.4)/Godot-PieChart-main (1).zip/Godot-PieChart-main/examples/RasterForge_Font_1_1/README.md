File: res://examples/RasterForge_Font_1_1/RasterForge.ttf
Source: https://ggbot.itch.io/raster-forge-font
Copyright: 2025, GGBotNet
License: CC0-1.0

This is used as part of a `theme` in the "Kiribati" pie chart.
